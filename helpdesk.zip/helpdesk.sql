-- MySQL dump 10.13  Distrib 5.7.20, for Win32 (AMD64)
--
-- Host: localhost    Database: helpdesk
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'Joko Wandiro','admin@demo.com','fe01ce2a7fbac8fafaed7c982a04e229','2017-07-07 12:46:39','2019-09-04 09:12:11');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Hardware','2019-08-09 04:48:53','2019-08-19 08:26:51'),(2,'Software','2019-08-09 04:48:53','2019-08-19 08:26:51'),(3,'Network','2019-08-09 04:48:53','2019-08-19 08:26:51'),(14,'Newspaper','2019-08-23 07:05:24','2019-08-23 07:51:12'),(16,'Bingo','2019-08-23 08:21:58','2019-08-23 08:21:58'),(18,'Hip','2019-08-23 08:24:00','2019-08-23 08:24:00'),(19,'adfsa','2019-08-29 04:55:19','2019-08-29 04:55:19'),(20,'hjkl','2019-09-03 08:44:22','2019-09-03 08:44:22'),(21,'bnm,','2019-09-03 08:44:22','2019-09-03 08:44:22'),(22,'PHP','2019-09-03 08:44:22','2019-09-03 08:44:22'),(23,'Java','2019-09-03 08:44:22','2019-09-03 08:44:22'),(24,'C#','2019-09-03 08:44:22','2019-09-03 08:44:22'),(25,'Javascript','2019-09-03 08:45:05','2019-09-03 08:45:05'),(26,'ASP.net','2019-09-03 08:45:05','2019-09-03 08:45:05');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Customer Support','2019-08-19 08:13:17','2019-08-19 08:13:17'),(2,'Administration','2019-08-19 08:13:17','2019-08-19 08:13:17'),(3,'Marketing','2019-08-19 08:13:17','2019-08-19 08:13:17'),(8,'Sales_','2019-08-23 08:07:55','2019-08-23 08:08:46'),(9,'Engineering','2019-09-03 07:53:56','2019-09-03 07:54:05'),(10,'asdfg','2019-09-04 04:49:59','2019-09-04 04:49:59'),(11,'zxcv','2019-09-04 04:49:59','2019-09-04 04:49:59'),(12,'hjklm','2019-09-04 04:49:59','2019-09-04 04:49:59'),(13,'fghj','2019-09-04 04:49:59','2019-09-04 04:49:59'),(14,'ashj','2019-09-04 04:49:59','2019-09-04 04:49:59'),(15,'yuio','2019-09-04 04:49:59','2019-09-04 04:49:59'),(16,'poll','2019-09-04 04:49:59','2019-09-04 04:49:59');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_department` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `seat_number` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `FK_Employees_Departments_idx` (`id_department`),
  CONSTRAINT `FK_Employees_Departments` FOREIGN KEY (`id_department`) REFERENCES `departments` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,3,'Yusuf Purnama','6221422990','A4','2019-08-19 08:19:24','2019-08-20 08:17:17'),(8,1,'Cesilia','6221422990','A4','2019-08-20 08:18:43','2019-08-20 08:29:03'),(10,3,'Kevin Gabe','6221422990','A4','2019-08-20 08:28:19','2019-08-20 08:29:38'),(11,2,'Deby Gabe','6221422990','A4','2019-08-20 08:28:52','2019-08-20 08:29:25'),(12,2,'Feby Rahmawati','6221422990','A9','2019-08-22 03:04:55','2019-08-22 03:22:37'),(13,2,'Januar','6221422990','A4','2019-08-23 09:39:02','2019-08-23 09:39:02'),(14,2,'Jefri','021422999','A9','2019-09-03 08:37:35','2019-09-03 08:37:52'),(29,3,'Yusuf Purnama_','6221422990','A4','2019-08-19 08:19:24','2019-08-20 08:17:17'),(30,1,'Cesilia_','6221422990','A4','2019-08-20 08:18:43','2019-08-20 08:29:03'),(31,3,'Kevin Gabe_','6221422990','A4','2019-08-20 08:28:19','2019-08-20 08:29:38'),(32,2,'Deby Gabe_','6221422990','A4','2019-08-20 08:28:52','2019-08-20 08:29:25'),(33,2,'Feby Rahmawati_','6221422990','A9','2019-08-22 03:04:55','2019-08-22 03:22:37'),(34,2,'Januar_','6221422990','A4','2019-08-23 09:39:02','2019-08-23 09:39:02'),(35,2,'Jefri_','021422999','A9','2019-09-03 08:37:35','2019-09-03 08:37:52');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'open','2019-08-19 08:08:49','2019-08-19 08:08:49'),(2,'closed','2019-08-19 08:08:49','2019-08-19 08:08:49'),(3,'failed','2019-08-20 08:45:13','2019-08-20 08:48:27'),(4,'in progress','2019-08-20 08:45:57','2019-08-20 08:45:57'),(6,'pendings','2019-08-23 08:49:05','2019-08-23 08:53:39'),(10,'asdfg','2019-09-04 04:49:59','2019-09-04 04:49:59'),(11,'zxcv','2019-09-04 04:49:59','2019-09-04 04:49:59'),(12,'hjklm','2019-09-04 04:49:59','2019-09-04 04:49:59'),(13,'fghj','2019-09-04 04:49:59','2019-09-04 04:49:59'),(14,'ashj','2019-09-04 04:49:59','2019-09-04 04:49:59'),(15,'yuio','2019-09-04 04:49:59','2019-09-04 04:49:59'),(16,'poll','2019-09-04 04:49:59','2019-09-04 04:49:59');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_employee` bigint(20) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `id_status` bigint(20) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_Tickets_Status_idx` (`id_status`),
  KEY `FK_Tickets_Employees_idx` (`id_employee`),
  CONSTRAINT `FK_Tickets_Employees` FOREIGN KEY (`id_employee`) REFERENCES `employees` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_Tickets_Status` FOREIGN KEY (`id_status`) REFERENCES `status` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (2,1,'PC tidak bisa nyala','Saya tiba di kantor lalu saya nyalakan tidak bisa.\nApakah yang terjadi ?',1,'2019-08-14 09:23:34','2019-08-20 09:40:20'),(6,11,'Ms. PowerPoint error','Ms. PowerPoint tidak bisa kebuka aplikasinya.',3,'2019-08-21 04:51:55','2019-08-21 08:14:09'),(7,11,'Install aplikasi design grafis','Saya minta diinstallkan aplikasi design grafis',2,'2019-08-21 08:20:18','2019-08-21 08:22:01'),(9,1,'','',1,'2019-08-28 03:56:31','2019-08-28 03:56:31'),(10,1,'PC tidak bisa nyala','Saya tiba di kantor lalu saya nyalakan tidak bisa.\nApakah yang terjadi ?',1,'2019-08-14 09:23:34','2019-08-20 09:40:20'),(11,11,'Ms. PowerPoint error','Ms. PowerPoint tidak bisa kebuka aplikasinya.',3,'2019-08-21 04:51:55','2019-08-21 08:14:09'),(12,11,'Install aplikasi design grafis','Saya minta diinstallkan aplikasi design grafis',2,'2019-08-21 08:20:18','2019-08-21 08:22:01'),(13,1,'','',1,'2019-08-28 03:56:31','2019-08-28 03:56:31'),(14,1,'PC tidak bisa nyala','Saya tiba di kantor lalu saya nyalakan tidak bisa.\nApakah yang terjadi ?',1,'2019-08-14 09:23:34','2019-08-20 09:40:20'),(15,11,'Ms. PowerPoint error','Ms. PowerPoint tidak bisa kebuka aplikasinya.',3,'2019-08-21 04:51:55','2019-08-21 08:14:09'),(16,11,'Install aplikasi design grafis','Saya minta diinstallkan aplikasi design grafis',2,'2019-08-21 08:20:18','2019-08-21 08:22:01'),(17,1,'','',1,'2019-08-28 03:56:31','2019-08-28 03:56:31');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-04 16:20:46
